// StringConcatenationBenchmark.java
package com.test;



import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

import java.util.concurrent.TimeUnit;

@BenchmarkMode({Mode.AverageTime,  
 Mode.SampleTime})
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@State(Scope.Benchmark)
//@Fork(value = 1, warmups = 1, jvmArgs = {"-Xms2G", "-Xmx2G"})
@Fork(value = 1, warmups = 1, jvmArgs = {"-Xms2G", "-Xmx2G"},jvm = "C:/Program Files/Java/jdk-23/bin/java") 
//@Fork(value = 0) // Disable forking
@Warmup(iterations = 3, time = 1)
@Measurement(iterations = 5, time = 1)
public class StringConcatenationBenchmark {

    @Param({"100", "1000", "10000"})
    private int stringCount;

    @Benchmark
    public void stringConcatenation(Blackhole blackhole) {
        String result = "";
        for (int i = 0; i < stringCount; i++) {
            result += "hello";
        }
        blackhole.consume(result);
    }

    @Benchmark
    public void stringBuilderConcatenation(Blackhole blackhole) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < stringCount; i++) {
            sb.append("hello");
        }
        blackhole.consume(sb.toString());
    }

    // You don't need a main method here when running with Maven
    // Maven will use the exec-maven-plugin to run the benchmarks
}
