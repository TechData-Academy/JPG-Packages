/**
 * 
 */
/**
 * 
 */
module Test {
	requires java.management;
	requires org.slf4j;
}