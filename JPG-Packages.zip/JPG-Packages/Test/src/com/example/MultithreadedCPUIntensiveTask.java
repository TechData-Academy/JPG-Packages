package com.example;

//Java
import java.util.ArrayList;
import java.util.List;

public class MultithreadedCPUIntensiveTask {

    public static void main(String[] args) {

        // Create two threads for two cores
        Thread thread1 = new Thread(() -> {
            List<Object> objects = new ArrayList<>(); // List to hold objects
            while (true) { // Run indefinitely
                // Perform CPU-intensive calculations
                double result = 0;
                for (int i = 0; i < 1000000; i++) {
                    result += Math.sqrt(i) * Math.pow(i, 2);
                }

                // Create and store objects to generate garbage
                for (int i = 0; i < 10000; i++) { 
                    Object obj = new Object();
                    objects.add(obj); 
                }

                // Optionally clear the list periodically to release memory
                if (objects.size() > 1000000) { 
                    objects.clear();
                }
            }
        });

        // Create the second thread with the same logic
        Thread thread2 = new Thread(() -> {
            List<Object> objects = new ArrayList<>();
            while (true) {
                double result = 0;
                for (int i = 0; i < 1000000; i++) {
                    result += Math.sqrt(i) * Math.pow(i, 2);
                }
                for (int i = 0; i < 10000; i++) {
                    Object obj = new Object();
                    objects.add(obj);
                }
                if (objects.size() > 1000000) {
                    objects.clear();
                }
            }
        });

        // Start the threads
        thread1.start();
        thread2.start();
    }
}

       

