package com.example;

import java.util.ArrayList;
import java.util.List;

public class LeakyClass {
    private static List<Object> data = new ArrayList<>();
    public void addData(Object obj) {
          data.add(obj);
    }
}