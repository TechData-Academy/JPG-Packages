package com.example;



//Java
import java.util.*;

public class SetBasedExample {

 public static void main(String[] args) {
     List<Integer> list1 = Arrays.asList(1, 2, 3, 4, 5);
     List<Integer> list2 = Arrays.asList(3, 5, 7, 8);

     // Traditional approach (nested loops - O(n^2))
     List<Integer> commonElementsTraditional = new ArrayList<>();
     for (int num1 : list1) {
         for (int num2 : list2) {
             if (num1 == num2) {
                 commonElementsTraditional.add(num1);
                 break; // Avoid duplicates
             }
         }
     }

     // Set-based approach (retainAll - O(n))
     Set<Integer> set1 = new HashSet<>(list1);
     Set<Integer> set2 = new HashSet<>(list2);
     set1.retainAll(set2); // Intersection of sets

     System.out.println("Common elements (traditional): " + commonElementsTraditional);
     System.out.println("Common elements (set-based): " + set1);
 }
}
