package com.example;

//Java
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class AtomicIntegerVsInteger {

    private static final int NUM_THREADS = 10;
    private static final int NUM_ITERATIONS = 1000000000;

    private static int integerCounter = 0;
    private static AtomicInteger atomicIntegerCounter = new AtomicInteger(0);

    public static void main(String[] args) throws InterruptedException {
        // Test with Integer
        long startTime = System.nanoTime();
        ExecutorService executor = Executors.newFixedThreadPool(NUM_THREADS);
        for (int i = 0; i < NUM_THREADS; i++) {
            executor.execute(() -> {
                for (int j = 0; j < NUM_ITERATIONS; j++) {
                    incrementIntegerCounter();
                }
            });
        }
        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.HOURS);
        long endTime = System.nanoTime();
        System.out.println("Integer counter: " + integerCounter);
        System.out.println("Time taken with Integer: " + (endTime - startTime) / 1_000_000 + " ms");

        // Test with AtomicInteger
        startTime = System.nanoTime();
        executor = Executors.newFixedThreadPool(NUM_THREADS);
        for (int i = 0; i < NUM_THREADS; i++) {
            executor.execute(() -> {
                for (int j = 0; j < NUM_ITERATIONS; j++) {
                    atomicIntegerCounter.incrementAndGet();
                }
            });
        }
        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.HOURS);
        endTime = System.nanoTime();
        System.out.println("AtomicInteger counter: " + atomicIntegerCounter.get());
        System.out.println("Time taken with AtomicInteger: " + (endTime - startTime) / 1_000_000 + " ms");
    }

    private static synchronized void incrementIntegerCounter() {
        integerCounter++;
    }
}