package com.example;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ConcurrentHashMapExample {

    private final ConcurrentHashMap<String, Integer> inventory = new ConcurrentHashMap<>();

    public void updateInventory(String item, int quantity) {
        inventory.put(item, quantity); // Thread-safe put operation
    }

    public int getQuantity(String item) {
        return inventory.getOrDefault(item, 0); // Thread-safe get operation
    }

    public static void main(String[] args) throws InterruptedException {
        ConcurrentHashMapExample example = new ConcurrentHashMapExample();
        ExecutorService 
 executor = Executors.newFixedThreadPool(10);

        // Simulate multiple threads updating the inventory
        for (int i = 0; i < 100; i++) {
            final int threadId = i;
            executor.execute(() -> {
                example.updateInventory("item-" + threadId, threadId * 10);
            });
        }

        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.HOURS);

        // Print the inventory contents
        System.out.println("Inventory contents:");
        example.inventory.forEach((item, quantity) -> System.out.println(item + ": " + quantity));
    }
}
