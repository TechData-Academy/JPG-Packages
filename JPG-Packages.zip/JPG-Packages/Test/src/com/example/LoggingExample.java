package com.example;

//Java
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggingExample {

    private static final Logger logger = LoggerFactory.getLogger(LoggingExample.class);  


    public String heavyMethod() {
        // Simulate a long-running operation
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return "This is the result of a heavy method";
    }

    public void logResult() {
        // Inefficient way
        logger.debug("Method result is : {}", this.heavyMethod());

        // More efficient way
        if (logger.isDebugEnabled()) {
            logger.debug("Method result is : {}", this.heavyMethod());
        }
    }

    public static void main(String[] args) {
        LoggingExample example = new LoggingExample();
        example.logResult();
    }
}