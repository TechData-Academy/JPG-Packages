package com.example;

// Java
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggingPerformanceTest {

    private static final Logger logger = LoggerFactory.getLogger(LoggingPerformanceTest.class);  


    public String heavyMethod() {
        // Simulate a long-running operation
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return "This is the result of a heavy method";
    }

    public void logResultInefficiently() {
        logger.debug("Method result is : {}", this.heavyMethod());
    }

    public void logResultEfficiently() {
        if (logger.isDebugEnabled()) {
            logger.debug("Method result is : {}", this.heavyMethod());
        }
    }

    public static void main(String[] args) {
        LoggingPerformanceTest test = new LoggingPerformanceTest();

        // Test inefficient logging
        long startTime = System.nanoTime();
        test.logResultInefficiently();
        long endTime = System.nanoTime();
        long inefficientTime = endTime - startTime;

        // Test efficient logging
        startTime = System.nanoTime();
        test.logResultEfficiently();
        endTime = System.nanoTime();
        long efficientTime = endTime - startTime;

        System.out.println("Inefficient logging time: " + inefficientTime + " ns");
        System.out.println("Efficient logging time: " + efficientTime + " ns");

        // Memory usage comparison is more complex and requires profiling tools
        // as the memory usage can fluctuate significantly during runtime.
    }
}