package com.example;

//Java
import java.util.concurrent.TimeUnit;

public class ObjectPoolExample {

    private static final int NUM_ITERATIONS = 1000;

    public static void main(String[] args) {
        // Without object pool
        long startTime = System.nanoTime();
        withoutObjectPool();
        long endTime = System.nanoTime();
        long durationWithoutPool = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);

        // With object pool
        startTime = System.nanoTime();
        withObjectPool();
        endTime = System.nanoTime();
        long durationWithPool = TimeUnit.NANOSECONDS.toMillis(endTime - startTime);

        System.out.println("Execution time without object pool: " + durationWithoutPool + " ms");
        System.out.println("Execution time with object pool: " + durationWithPool + " ms");

        // Get memory usage (approximate)
        Runtime runtime = Runtime.getRuntime();
        long memoryUsedWithoutPool = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("Approximate memory used without pool: " + memoryUsedWithoutPool + " bytes");

        // Run with object pool again to measure memory usage after pool creation
        withObjectPool();
        long memoryUsedWithPool = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("Approximate memory used with pool: " + memoryUsedWithPool + " bytes");
    }

    private static void withoutObjectPool() {
        for (int i = 0; i < NUM_ITERATIONS; i++) {
            ExpensiveObject obj = new ExpensiveObject();
            // Use the object
        }
    }

    private static void withObjectPool() {
        ObjectPool<ExpensiveObject> pool = new ObjectPool<>(10, () -> new ExpensiveObject());
        for (int i = 0; i < NUM_ITERATIONS; i++) {
            ExpensiveObject obj = pool.borrowObject();
            // Use the object
            pool.returnObject(obj);
        }
    }

    static class ExpensiveObject {
        // Simulate expensive creation
        public ExpensiveObject() {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // Simple object pool implementation
    static class ObjectPool<T> {
        private final int poolSize;
        private final java.util.Queue<T> pool;
        private final java.util.function.Supplier<T> objectCreator;

        public ObjectPool(int poolSize, java.util.function.Supplier<T> objectCreator) {
            this.poolSize = poolSize;
            this.pool = new java.util.LinkedList<>();
            this.objectCreator = objectCreator;
            for (int i = 0; i < poolSize; i++) {
                pool.offer(objectCreator.get());
            }
        }

        public T borrowObject() {
            if (pool.isEmpty()) {
                return objectCreator.get();
            } else {
                return pool.poll();
            }
        }

        public void returnObject(T obj) {
            if (pool.size() < poolSize) {
                pool.offer(obj);
            }
        }
    }
}