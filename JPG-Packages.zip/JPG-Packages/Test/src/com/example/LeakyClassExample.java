package com.example;



public class LeakyClassExample {

    public static void main(String[] args) {
        LeakyClass leaky = new LeakyClass();

        // Add a million objects to the static list in LeakyClass
        for (int i = 0; i < 1000000; i++) {
            leaky.addData(new Object()); 
        }

        // The 'data' list in LeakyClass now holds a huge amount of data

        // Even if we try to force garbage collection...
        System.gc(); 

        // ...the memory used by those million objects won't be freed!
        // This is because the 'data' list (which is static) still has 
        // strong references to all those objects, preventing them 
        // from being garbage collected. 
    }
}
