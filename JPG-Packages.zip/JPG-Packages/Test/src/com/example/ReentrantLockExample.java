package com.example;

//Java
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockExample {

    private final ReentrantLock lock = new ReentrantLock();
    private int counter = 0;

    public void incrementCounter() {
        lock.lock(); // Acquire the lock
        try {
            counter++;
            System.out.println("Counter value: " + counter); // Print the counter value
        } finally {
            lock.unlock(); // Always release the lock in the finally block
        }
    }

    public static void main(String[] args) throws InterruptedException {
        ReentrantLockExample example = new ReentrantLockExample(); 
        ExecutorService executor = Executors.newFixedThreadPool(10);

        for (int i = 0; i < 100; i++) {
            executor.execute(example::incrementCounter);
        }

        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.HOURS);
        System.out.println("Final counter value: " + example.counter);
    }
}