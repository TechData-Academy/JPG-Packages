package com.example;

//Java
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class ResourceHog {

  public static void main(String[] args) {
      List<BigInteger> bigNumbers = new ArrayList<>();

      // Inefficient loop that generates and stores large BigIntegers
      while (true) {
          bigNumbers.add(fibonacci(100000)); // Calculate a very large Fibonacci number
      }
  }

  // Inefficient recursive Fibonacci calculation
  private static BigInteger fibonacci(int n) {
      if (n <= 1) {
          return BigInteger.valueOf(n);
      } else {
          return fibonacci(n - 1).add(fibonacci(n - 2));
      }
  }
}

