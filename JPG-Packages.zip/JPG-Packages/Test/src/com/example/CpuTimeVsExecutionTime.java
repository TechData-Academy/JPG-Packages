package com.example;

//Java
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import java.util.Random;

//Java

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.util.ArrayList;

public class CpuTimeVsExecutionTime {



	    public static void main(String[] args) throws Exception {
	        // Get ThreadMXBean instance
	        ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();

	        // Check if thread CPU time measurement is supported and enable it
	        if (threadMXBean.isThreadCpuTimeSupported() && !threadMXBean.isThreadCpuTimeEnabled()) {
	            threadMXBean.setThreadCpuTimeEnabled(true);
	        }

	        int numThreads = 4;  // Number of threads to use
	        int numIterations = 1000000;  // Total number of iterations
	        ExecutorService executorService = Executors.newFixedThreadPool(numThreads);
	        List<Future<Result>> futures = new ArrayList<>();

	        // Measure execution time before starting the threads
	        long startTime = System.nanoTime();

	        // Submit tasks to the thread pool
	        for (int i = 0; i < numThreads; i++) {
	            Callable<Result> task = new SumTask(threadMXBean, numIterations / numThreads);
	            futures.add(executorService.submit(task));
	        }

	        // Aggregate results and CPU time
	        int totalSum = 0;
	        long totalCpuTime = 0;
	        for (Future<Result> future : futures) {
	            Result result = future.get();  // Get the sum and CPU time from each thread
	            totalSum += result.sum;
	            totalCpuTime += result.cpuTime;
	        }

	        // Measure execution time after all tasks are completed
	        long endTime = System.nanoTime();
	        long executionTime = endTime - startTime;

	        // Shutdown the executor service
	        executorService.shutdown();
	        executorService.awaitTermination(1, TimeUnit.MINUTES);

	        // Print the results
	        System.out.println("Total Sum: " + totalSum);
	        System.out.println("Execution time: " + executionTime + " nanoseconds");
	        System.out.println("Total CPU time: " + totalCpuTime + " nanoseconds");
	    }

	    // Task to calculate a part of the sum and measure its CPU time
	    static class SumTask implements Callable<Result> {
	        private final int iterations;
	        private final ThreadMXBean threadMXBean;

	        SumTask(ThreadMXBean threadMXBean, int iterations) {
	            this.threadMXBean = threadMXBean;
	            this.iterations = iterations;
	        }

	        @Override
	        public Result call() throws Exception {
	            long threadId = Thread.currentThread().getId();
	            long startCpuTime = threadMXBean.getThreadCpuTime(threadId);

	            Random random = new Random();
	            int sum = 0;
	            for (int i = 0; i < iterations; i++) {
	                sum += random.nextInt();
	            }

	            long endCpuTime = threadMXBean.getThreadCpuTime(threadId);
	            long cpuTime = endCpuTime - startCpuTime;

	            return new Result(sum, cpuTime);
	        }
	    }

	    // Helper class to store the result of each task (sum and CPU time)
	    static class Result {
	        int sum;
	        long cpuTime;

	        Result(int sum, long cpuTime) {
	            this.sum = sum;
	            this.cpuTime = cpuTime;
	        }
	    }
	}