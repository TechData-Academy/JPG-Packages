package com.example;



//Java

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexVsStringManipulationBenchmark {

 private static final int NUM_ITERATIONS = 1000000;
 private static final String text = "My name is Imad BELKACEM and you can reach me at imadbelkaceminfo@gmail.com or " +
         "imad.belkacem@univ-tours.fr. This is a test with some@email.addresses to extract.";

 public static void main(String[] args) {
     long startTime, endTime;
     Runtime runtime = Runtime.getRuntime();
     long usedMemoryBefore, usedMemoryAfter;

     // Benchmark using regular expressions
     System.gc();
     startTime = System.nanoTime();
     usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
     for (int i = 0; i < NUM_ITERATIONS; i++) {
         extractEmailsWithRegex(text);
     }
     endTime = System.nanoTime();
     usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
     System.gc();
     System.out.println("Using regular expressions:");
     System.out.println("Execution time: " + (endTime - startTime) / 1000000 + " ms");
     System.out.println("Memory used: " + (usedMemoryAfter - usedMemoryBefore) + " bytes");

     // Benchmark using string manipulation
     System.gc();
     startTime = System.nanoTime();
     usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
     for (int i = 0; i < NUM_ITERATIONS; i++) {
         extractEmailsWithStringManipulation(text);
     }
     endTime = System.nanoTime();
     usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
     System.gc();
     System.out.println("\nUsing string manipulation:");
     System.out.println("Execution time: " + (endTime - startTime) / 1000000 + " ms");
     System.out.println("Memory used: " + (usedMemoryAfter - usedMemoryBefore) + " bytes");
 }

 private static void extractEmailsWithRegex(String text) {
     Pattern pattern = Pattern.compile("\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b");
     Matcher matcher = pattern.matcher(text);
     while (matcher.find()) {
         // You can comment out this line if you don't need to print the emails
         // System.out.println(matcher.group()); 
     }
 }

 private static void extractEmailsWithStringManipulation(String text) {
     int atIndex = text.indexOf('@');
     while (atIndex != -1) {
         int start = text.lastIndexOf(' ', atIndex) + 1;
         int end = text.indexOf(' ', atIndex);
         if (end == -1) {
             end = text.length();
         }
         // You can comment out this line if you don't need to print the emails
          System.out.println(text.substring(start, end)); 
         atIndex = text.indexOf('@', end);
         
     }
 }
}
