package com.example;

// Java

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class OrderProcessorBenchmark {

    private static final int NUM_ORDERS = 10000;

    public static void main(String[] args) {
        List<Order> orders = generateOrders(NUM_ORDERS);

        long startTime, endTime;
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore, usedMemoryAfter;

        // Benchmark original processOrder
        startTime = System.nanoTime();
        usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
        for (Order order : orders) {
            new OrderProcessorOriginal().processOrder(order);
        }
        endTime = System.nanoTime();
        usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("Original processOrder:");
        System.out.println("Execution time: " + (endTime - startTime) / 1000000 + " ms");
        System.out.println("Memory used: " + (usedMemoryAfter - usedMemoryBefore) / 1024 + " KB");

        // Benchmark refactored processOrder
        startTime = System.nanoTime();
        usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
        for (Order order : orders) {
            new OrderProcessorRefactored().processOrder(order);
        }
        endTime = System.nanoTime();
        usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("\nRefactored processOrder:");
        System.out.println("Execution time: " + (endTime - startTime) / 1000000 + " ms");
        System.out.println("Memory used: " + (usedMemoryAfter - usedMemoryBefore) / 1024 + " KB");
    }

    private static List<Order> generateOrders(int numOrders) {
        List<Order> orders = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < numOrders; i++) {
            Customer customer = new Customer("Customer " + i, random.nextBoolean());
            List<OrderItem> items = new ArrayList<>();
            int numItems = random.nextInt(5) + 1; // 1 to 5 items per order
            for (int j = 0; j < numItems; j++) {
                items.add(new OrderItem("Product " + j, random.nextDouble() * 100, random.nextInt(5) + 1));
            }
            orders.add(new Order(customer, items));
        }
        return orders;
    }
}

class OrderProcessorOriginal {
    public void processOrder(Order order) {
        // Validate order details
        if (order.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must contain at least one item");
        }
        if (order.getCustomer() == null) {
            throw new IllegalArgumentException("Order must have a customer");
        }
        // Calculate total price
        double totalPrice = 0.0;
        for (OrderItem item : order.getItems()) {
            totalPrice += item.getPrice() * item.getQuantity();
        }
        // Apply discounts
        if (order.getCustomer().isPremiumMember()) {
            totalPrice *= 0.9; // 10% discount for premium members
        }
        // Generate invoice
        Invoice invoice = new Invoice(order.getCustomer(), order.getItems(), totalPrice);
        // Send email notification
        sendEmailNotification(order.getCustomer().getEmail(), invoice);
        // Update inventory
        for (OrderItem item : order.getItems()) {
            updateInventory(item.getProductId(), item.getQuantity());
        }
    }

    // ... other methods (sendEmailNotification, updateInventory)
    private void sendEmailNotification(String email, Invoice invoice) {
        // Simulate sending email
    }

    private void updateInventory(String productId, int quantity) {
        // Simulate updating inventory
    }
}

class OrderProcessorRefactored {
    public void processOrder(Order order) {
        validateOrder(order);
        double totalPrice = calculateTotalPrice(order);
        Invoice invoice = generateInvoice(order, totalPrice);
        sendEmailNotification(order.getCustomer().getEmail(), invoice);
        updateInventory(order);
    }

    private void validateOrder(Order order) {
        if (order.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must contain at least one item");
        }
        if (order.getCustomer() == null) {
            throw new IllegalArgumentException("Order must have a customer");
        }
    }

    private double calculateTotalPrice(Order order) {
        double totalPrice = 0.0;
        for (OrderItem item : order.getItems()) {
            totalPrice += item.getPrice() * item.getQuantity();
        }
        if (order.getCustomer().isPremiumMember()) {
            totalPrice *= 0.9;
        }
        return totalPrice;
    }

    private Invoice generateInvoice(Order order, double totalPrice) {
        return new Invoice(order.getCustomer(), order.getItems(), totalPrice);
    }

    private void updateInventory(Order order) {
        for (OrderItem item : order.getItems()) {
            updateInventory(item.getProductId(), item.getQuantity());
        }
    }

    // ... other methods (sendEmailNotification, updateInventory)
    private void sendEmailNotification(String email, Invoice invoice) {
        // Simulate sending email
    }

    private void updateInventory(String productId, int quantity) {
        // Simulate updating inventory
    }
}

class Order {
    private Customer customer;
    private List<OrderItem> items;

    public Order(Customer customer, List<OrderItem> items) {
        this.customer = customer;
        this.items = items;
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<OrderItem> getItems() {
        return items;
    }
}

class OrderItem {
    private String productId;
    private double price;
    private int quantity;

    public OrderItem(String productId, double price, int quantity) {
        this.productId = productId;
        this.price = price;
        this.quantity = quantity;
    }

    public String getProductId() {
        return productId;  

    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;  

    }
}

class Customer {
    private String name;
    private boolean premiumMember;

    public Customer(String name, boolean premiumMember) {
        this.name = name;
        this.premiumMember = premiumMember;
    }

    public String getName() {
        return name;
    }

    public boolean isPremiumMember() {
        return premiumMember;
    }

    public String getEmail() {
        return name.toLowerCase() + "@example.com";
    }
}

class Invoice {
    private Customer customer;
    private List<OrderItem> items;
    private double totalPrice;

    public Invoice(Customer customer, List<OrderItem> items, double totalPrice) {
        this.customer = customer;
        this.items = items;
        this.totalPrice = totalPrice;
    }
    // ... other methods
}
