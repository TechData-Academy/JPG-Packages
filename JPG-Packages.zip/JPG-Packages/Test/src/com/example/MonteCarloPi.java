package com.example;

//Java
public class MonteCarloPi {

  public static void main(String[] args) {
      long numPoints = 1000000000L; // 1 billion points
      long pointsInsideCircle = 0;
      
      for (long i = 0; i < numPoints; i++) {
          double x = Math.random();
          double y = Math.random();
          
          if (x * x + y * y <= 1) {
              pointsInsideCircle++;
          }
      }
      
      double piEstimate = 4.0 * pointsInsideCircle / numPoints;
      System.out.println("Estimated value of Pi: " + piEstimate);
  }
}

