package com.example;

//Java

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class HashMapVsTreeMap {

    public static void main(String[] args)  
 {
        int numElements = 5000000; // Or 5000000 for the larger test

        // HashMap test
        Map<Integer, Integer> hashMap = new HashMap<>();
        long startTime = System.nanoTime();
        for (int i = 0; i < numElements; i++) {
            hashMap.put(i, i);
        }
        long endTime = System.nanoTime();
        System.out.println("HashMap insertion time: " + (endTime - startTime) + " ns");

        startTime = System.nanoTime();
        for (int i = 0; i < numElements; i++) {
            hashMap.get(i);
        }
        endTime = System.nanoTime();
        System.out.println("HashMap retrieval time: " + (endTime - startTime) + " ns");

        // TreeMap test
        Map<Integer, Integer> treeMap = new TreeMap<>();
        startTime = System.nanoTime();
        for (int i = 0; i < numElements; i++) {
            treeMap.put(i, i);
        }
        endTime = System.nanoTime();
        System.out.println("TreeMap insertion time: " + (endTime - startTime) + " ns");

        startTime = System.nanoTime();
        for (int i = 0; i < numElements; i++) {
            treeMap.get(i);
        }
        endTime = System.nanoTime();
        System.out.println("TreeMap retrieval time: " + (endTime - startTime) + " ns");
    }
}
