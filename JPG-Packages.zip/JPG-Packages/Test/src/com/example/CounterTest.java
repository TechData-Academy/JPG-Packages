package com.example;

public class CounterTest {

    private final Object lock = new Object();
    private int counter = 0;

    public void incrementCounter() {
        synchronized (lock) {
            counter++;
        }
    }

    public static void main(String[] args) {
        CounterTest counterTest = new CounterTest();
        int numThreads = 10;
        int numIncrements = 10000;

        // Create and start threads
        Thread[] threads = new Thread[numThreads];
        for (int i = 0; i < numThreads; i++) {
            threads[i] = new Thread(() -> {
                for (int j = 0; j < numIncrements; j++) {
                    counterTest.incrementCounter();
                }
            });
            threads[i].start();
        }

        // Wait for threads to finish
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();  

            }
        }

        // Print the final counter value
        System.out.println("Final counter value: " + counterTest.counter);  

    }
}