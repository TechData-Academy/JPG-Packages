package com.example;

// Java

import java.util.ArrayList;
import java.util.List;

class Book {
    private String title;

    public Book(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}

public class  
 BookSearch {

    public static void main(String[] args) {
        // Create a large list of books
        List<Book> books = new ArrayList<>();
        books.add(new Book("The Lord of the Rings"));
        books.add(new Book("The Da Vinci Code")); 
        books.add(new Book("The Hitchhiker's Guide to the Galaxy"));
        // ... add many more books ...
        books.add(new Book("Frankenstein in Baghdad\" by Ahmed Saadawi")); 

        // Target book to find
        Book targetBook = new Book("The Hitchhiker's Guide to the Galaxy");

        // Search for the target book
        boolean found = false;
        for (Book book : books) {
            if (book.getTitle().equals(targetBook.getTitle())) {
                System.out.println("Found the book: " + book.getTitle());
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Book not found.");
        }
    }
}