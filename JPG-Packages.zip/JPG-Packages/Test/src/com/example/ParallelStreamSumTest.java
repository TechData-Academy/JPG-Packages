package com.example;

//Java
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ParallelStreamSumTest {

    public static void main(String[] args) {
        // Generate a large list of random numbers
        List<Integer> numbers = generateRandomNumbers(1000000);

        // Calculate the sum of even numbers using a parallel stream
        long startTime = System.currentTimeMillis();
        int sum = numbers.parallelStream()
                .filter(n -> n % 2 == 0)
                .mapToInt(Integer::intValue)
                .sum();
        long endTime = System.currentTimeMillis();

        System.out.println("Sum of even numbers: " + sum);
        System.out.println("Time taken (parallel): " + (endTime - startTime) + " ms");

        // Calculate the sum of even numbers using a sequential stream for comparison
        startTime = System.currentTimeMillis();
        sum = numbers.stream()
                .filter(n -> n % 2 == 0)
                .mapToInt(Integer::intValue)
                .sum();
        endTime = System.currentTimeMillis();

        System.out.println("Sum of even numbers (sequential): " + sum);
        System.out.println("Time taken (sequential): " + (endTime - startTime) + " ms");
    }

    private static List<Integer> generateRandomNumbers(int count) {
        List<Integer> numbers = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < count; i++) {
            numbers.add(random.nextInt(1000));  

        }
        return numbers;
    }
}