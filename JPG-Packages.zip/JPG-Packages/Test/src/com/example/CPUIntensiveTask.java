package com.example;

//Java
public class CPUIntensiveTask {

    public static void main(String[] args) {

        long startTime = System.currentTimeMillis();
        long endTime = startTime + 60 * 1000; // Run for 1 minute

        while (System.currentTimeMillis() < endTime) {
            // Perform CPU-intensive calculations
            double result = 0;
            for (int i = 0; i < 1000000; i++) {
                result += Math.sqrt(i) * Math.pow(i, 2);
            }
        }

        System.out.println("CPU-intensive task completed.");
    }
}