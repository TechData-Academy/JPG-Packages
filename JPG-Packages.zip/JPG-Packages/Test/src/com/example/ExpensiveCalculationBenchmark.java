package com.example;

// Java

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class ExpensiveCalculationBenchmark {

    private static final int NUM_CALCULATIONS = 400; // You can adjust this value

    public static void main(String[] args) {
        Random random = new Random();
        int[] inputs = new int[NUM_CALCULATIONS];
        for (int i = 0; i < NUM_CALCULATIONS; i++) {
            inputs[i] = random.nextInt(NUM_CALCULATIONS / 10); 
        }

        long startTime, endTime;
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore, usedMemoryAfter;

        // Benchmark without caching
        ExpensiveCalculationWithoutCache calculatorWithoutCache = new ExpensiveCalculationWithoutCache();
        System.gc(); // Add this line to suggest garbage collection
        startTime = System.nanoTime();
        usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
        for (int input : inputs) {
            calculatorWithoutCache.calculateExpensiveValue(input);
        }
        endTime = System.nanoTime();
        usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        System.gc(); // Add this line to suggest garbage collection
        System.out.println("Without caching:");
        System.out.println("Execution time: " + (endTime - startTime) / 1000000 + " ms");
        System.out.println("Memory used: " + (usedMemoryAfter - usedMemoryBefore) + " bytes"); 

        // Benchmark with caching
        ExpensiveCalculationWithCache calculatorWithCache = new ExpensiveCalculationWithCache();
        System.gc(); // Add this line to suggest garbage collection
        startTime = System.nanoTime();
        usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
        for (int input : inputs) {
            calculatorWithCache.calculateExpensiveValue(input);
        }
        endTime = System.nanoTime();
        usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        System.gc(); // Add this line to suggest garbage collection
        System.out.println("\nWith caching:");
        System.out.println("Execution time: " + (endTime - startTime) / 1000000 + " ms");
        System.out.println("Memory used: " + (usedMemoryAfter - usedMemoryBefore) + " bytes"); 
    }
}

class ExpensiveCalculationWithoutCache {
    public int calculateExpensiveValue(int input) {
        return fibonacci(input);
    }

    private int fibonacci(int n) {
        if (n <= 1) {
            return n;
        }
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}

class ExpensiveCalculationWithCache {
    private Map<Integer, Integer> cache = new HashMap<>();

    public int calculateExpensiveValue(int input) {
        if (cache.containsKey(input)) {
            return cache.get(input); 
        } else {
            int result = fibonacci(input);
            cache.put(input, result);
            return result;
        }
    }

    private int fibonacci(int n) {
        if (n <= 1) {
            return n;
        }
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}