package com.example;

//Java
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;

public class CpuTimeTest {
    public static void main(String[] args) {
        // Simulate some CPU-intensive work
        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < 5000) { // Run for 5 seconds
            // Perform calculations or tasks that consume CPU time
            for (int i = 0; i < 1000000; i++) {
                Math.sqrt(i);
            }
        }

        // Get total CPU time for all threads
        long totalCpuTime = 0;
        ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
        for (long threadId : threadMXBean.getAllThreadIds()) {
            long cpuTime = threadMXBean.getThreadCpuTime(threadId);
            totalCpuTime += cpuTime;
        }

        System.out.println("Total CPU time for all threads: " + totalCpuTime + " nanoseconds");
    }
}
