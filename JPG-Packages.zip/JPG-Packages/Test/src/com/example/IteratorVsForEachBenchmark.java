package com.example;

//Java

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IteratorVsForEachBenchmark {

    private static final int NUM_ELEMENTS = 100000000;

    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < NUM_ELEMENTS; i++) {
            numbers.add(i);
        }

        long startTime, endTime;
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore, usedMemoryAfter;

        // Benchmark using an iterator
        System.gc();
        startTime = System.nanoTime();
        usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
        useIterator(numbers);
        endTime = System.nanoTime();
        usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        System.gc();
        System.out.println("Using iterator:");
        System.out.println("Execution time: " + (endTime - startTime) / 1000000 + " ms");
        System.out.println("Memory used: " + (usedMemoryAfter - usedMemoryBefore) + " bytes");

        // Benchmark using a for-each loop
        System.gc();
        startTime = System.nanoTime();
        usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
        useForEach(numbers);
        endTime = System.nanoTime();
        usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        System.gc();
        System.out.println("\nUsing for-each loop:");
        System.out.println("Execution time: " + (endTime - startTime) / 1000000 + " ms");
        System.out.println("Memory used: " + (usedMemoryAfter - usedMemoryBefore) + " bytes");
    }

    private static void useIterator(List<Integer> numbers) {
        Iterator<Integer> iterator = numbers.iterator();
        while (iterator.hasNext()) {
            int number = iterator.next();
            // Do something with the number (e.g., number * 2)
        }
    }

    private static void useForEach(List<Integer> numbers) {
        for (int number : numbers) {
            // Do something with the number (e.g., number * 2)
        }
    }
}