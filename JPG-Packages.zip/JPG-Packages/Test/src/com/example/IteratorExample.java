package com.example;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IteratorExample {

    public static void main(String[] args)  
 {
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 1000000; i++) {
            numbers.add(i);
        }

        // Using an iterator
        long startTime = System.currentTimeMillis();
        Iterator<Integer> iterator = numbers.iterator();
        while (iterator.hasNext()) {
            int number = iterator.next();
            // Do something with the number
        }
        long endTime = System.currentTimeMillis();
        System.out.println("Time taken with iterator: " + (endTime - startTime) + "ms");

        // Using a for-each loop
        startTime = System.currentTimeMillis();
        for (int number : numbers) {
            // Do something with the number
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time taken with for-each: " + (endTime - startTime) + "ms");
    }
}

