package com.example;

//Java

import java.util.*;

class Book3 {
    private String title;
    private String author;

    // Constructor and getters (for testing)
    public Book3(String title, String author) {
        this.title = title;
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    // Inefficient hashCode() implementation - only considers title
    public int hashCodeInefficient() {
        return title.hashCode();
    }

    // Improved hashCode() implementation
    public int hashCodeImproved() {
        int result = 17; // Prime number for better distribution
        result = 31 * result + title.hashCode();
        result = 31 * result + author.hashCode();
        return result;
    }

    // equals() method (same for both implementations)
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Book3 book = (Book3) obj;
        return title.equals(book.title) && author.equals(book.author);
    }
}

public class HashCodeEqualsComparison {

    public static void main(String[] args) {
        int numBooks = 100000; // Number of books

        // Run performance tests with inefficient hashCode()
        runPerformanceTest("Inefficient hashCode()", () -> testHashMap(createBooksWithInefficientHashCode(numBooks)));

        // Run performance tests with improved hashCode()
        runPerformanceTest("Improved hashCode()", () -> testHashMap(createBooksWithImprovedHashCode(numBooks)));
    }

    // Create books with inefficient hashCode() implementation
    static List<Book3> createBooksWithInefficientHashCode(int numBooks) {
        List<Book3> books = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < numBooks; i++) {
            books.add(new Book3("Book " + random.nextInt(1000), "Author " + i));
        }
        return books;
    }

    // Create books with improved hashCode() implementation
    static List<Book3> createBooksWithImprovedHashCode(int numBooks) {
        List<Book3> books = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < numBooks; i++) {
            books.add(new Book3("Book " + random.nextInt(1000), "Author " + i));
        }
        return books;
    }

    // Test HashMap performance with a list of books
    static void testHashMap(List<Book3> books) {
        Map<Book3, Integer> bookMap = new HashMap<>();
        // Add books to the map
        for (int i = 0; i < books.size(); i++) {
            bookMap.put(books.get(i), i);
        }
        // Retrieve a book from the map
        Book3 targetBook = books.get(books.size() / 2);
        bookMap.get(targetBook);
    }

    static void runPerformanceTest(String testName, Runnable testMethod) {
        long startTime = System.nanoTime();
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();

        testMethod.run(); // Run the test method

        long endTime = System.nanoTime();
        runtime.gc();
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

        long executionTime = endTime - startTime;
        System.out.println(testName + ":");
        System.out.println("  Execution time: " + executionTime + " ns");
        System.out.println("  Memory used: " + memoryUsed + " bytes");
        System.out.println("----------------------");
    }
}
