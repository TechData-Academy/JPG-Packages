package com.example;

//Java

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;  

import java.util.ArrayList;
import java.util.List;  


public class PerformanceMetrics2 {
    public static void main(String[] args) {
        // Record start time
        long startTime = System.nanoTime();

        // Simulate some work that generates garbage
        performWork();

        // Record end time
        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;

        // Calculate CPU utilization
        long totalCpuTime = getTotalCpuTime();
        double cpuUtilization = (double) totalCpuTime / elapsedTime * 100;

        // Calculate garbage collection overhead
        long totalGcTime = getTotalGcTime();
        double gcOverhead = (double) totalGcTime / elapsedTime * 100;

        // Print the results
        System.out.println("Elapsed Time: " + elapsedTime + " nanoseconds");
        System.out.println("CPU Utilization: " + cpuUtilization + "%");
        System.out.println("Garbage Collection Overhead: " + gcOverhead + "%");
    }

  //Java
    private static void performWork() {
        List<Object> objects = new ArrayList<>();
        for (int i = 0; i < 5000000; i++) { // Reduced number of objects
            objects.add(new byte[512]); // Smaller array size
        }
    }


    // Get total CPU time for all threads
    private static long getTotalCpuTime() {
        ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
        long totalCpuTime = 0;
        for (long threadId : threadMXBean.getAllThreadIds()) {
            totalCpuTime += threadMXBean.getThreadCpuTime(threadId);
        }
        return totalCpuTime;
    }

    // Get total garbage collection time
    private static long getTotalGcTime() {
        long totalGcTime = 0;
        for (GarbageCollectorMXBean gcBean : ManagementFactory.getGarbageCollectorMXBeans()) {
            totalGcTime += gcBean.getCollectionTime();
        }
        return totalGcTime;  

    }
}
