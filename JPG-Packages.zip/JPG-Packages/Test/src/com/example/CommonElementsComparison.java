package com.example;

import java.util.*;
public class CommonElementsComparison {

	
       public static void main(String[] args) {
	        int numElements = 100000; // Adjust the number of elements as needed

	        // Run performance tests for the traditional approach
	        runPerformanceTest("Traditional Approach", () -> findCommonElementsTraditional(generateLists(numElements)));

	        // Run performance tests for the set-based approach
	        runPerformanceTest("Set-based Approach", () -> findCommonElementsSetBased(generateLists(numElements)));
	    }

	    // Generate lists with random numbers
	    static List<List<Integer>> generateLists(int numElements) {
	        List<Integer> list1 = new ArrayList<>();
	        List<Integer> list2 = new ArrayList<>();
	        Random random = new Random();
	        for (int i = 0; i < numElements; i++) {
	            list1.add(random.nextInt(numElements));
	            list2.add(random.nextInt(numElements));
	        }
	        return Arrays.asList(list1, list2);
	    }

	    // Traditional approach (nested loops)
	    static List<Integer> findCommonElementsTraditional(List<List<Integer>> lists) {
	        List<Integer> list1 = lists.get(0);
	        List<Integer> list2 = lists.get(1);
	        List<Integer> commonElements = new ArrayList<>();
	        for (int num1 : list1) {
	            for (int num2 : list2) {
	                if (num1 == num2) {
	                    commonElements.add(num1);
	                    break; // Avoid duplicates
	                }
	            }
	        }
	        return commonElements;
	    }

	    // Set-based approach (retainAll)
	    static Set<Integer> findCommonElementsSetBased(List<List<Integer>> lists) {
	        List<Integer> list1 = lists.get(0);
	        List<Integer> list2 = lists.get(1);
	        Set<Integer> set1 = new HashSet<>(list1);
	        Set<Integer> set2 = new HashSet<>(list2);
	        set1.retainAll(set2); // Intersection of sets
	        return set1;
	    }

	    static void runPerformanceTest(String testName, Runnable testMethod) {
	        long startTime = System.nanoTime();
	        Runtime runtime = Runtime.getRuntime();
	        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();

	        testMethod.run(); // Run the test method

	        long endTime = System.nanoTime();
	        runtime.gc();
	        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
	        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

	        long executionTime = endTime - startTime;
	        System.out.println(testName + ":");
	        System.out.println("Execution time: " + executionTime + " ns");
	        System.out.println("Memory used: " + memoryUsed + " bytes");
	        System.out.println("----------------------");
	    }
	}
