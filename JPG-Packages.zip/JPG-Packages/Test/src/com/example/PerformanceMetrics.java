package com.example;

//Java

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;  


public class PerformanceMetrics {
    public static void main(String[] args) {
        // Record start time
        long startTime = System.nanoTime();

        // Simulate some work (replace with your actual program logic)
        performWork();

        // Record end time
        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;

        // Calculate CPU utilization
        long totalCpuTime = getTotalCpuTime();
        double cpuUtilization = (double) totalCpuTime / elapsedTime * 100;

        // Calculate throughput (replace with your actual transaction count)
        int numTransactions = 1000; // Example transaction count
        double throughput = (double) numTransactions / (elapsedTime / 1_000_000_000.0); // Transactions per second

        // Calculate average response time (replace with your actual response times)
        long totalResponseTime = 2000000000L; // Example total response time in nanoseconds
        int numRequests = 1000; // Example number of requests
        double avgResponseTime = (double) totalResponseTime / numRequests; // Average response time in nanoseconds

        // Calculate garbage collection overhead
        long totalGcTime = getTotalGcTime();
        double gcOverhead = (double) totalGcTime / elapsedTime * 100;

        // Print the results
        System.out.println("Elapsed Time: " + elapsedTime + " nanoseconds");
        System.out.println("CPU Utilization: " + cpuUtilization + "%");
        System.out.println("Throughput: " + throughput + " transactions/second");
        System.out.println("Average Response Time: " + avgResponseTime + " nanoseconds");
        System.out.println("Garbage Collection Overhead: " + gcOverhead + "%");
    }

    // Simulate some work (replace with your actual program logic)
    private static void performWork() {
        // Example work: Calculate Fibonacci sequence
        for (int i = 0; i < 45; i++) {
            fibonacci(i);
        }
    }

    // Example work: Calculate Fibonacci sequence
    private static long fibonacci(int n) {
        if (n <= 1) {
            return n;
        }
        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    // Get total CPU time for all threads
    private static long getTotalCpuTime() {
        ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
        long totalCpuTime = 0;
        for (long threadId : threadMXBean.getAllThreadIds()) {
            totalCpuTime += threadMXBean.getThreadCpuTime(threadId);
        }
        return totalCpuTime;
    }

    // Get total garbage collection time
    private static long getTotalGcTime() {
        long totalGcTime = 0;
        for (GarbageCollectorMXBean gcBean : ManagementFactory.getGarbageCollectorMXBeans()) {
            totalGcTime += gcBean.getCollectionTime();
        }
        return totalGcTime;  

    }
}