package com.example;

//Java
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.math.BigInteger;

public class TestJCMD {
    public static void main(String[] args) {
        // Simulate some CPU-intensive work
        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < 5000) { // Run for 5 seconds
            // Perform calculations or tasks that consume CPU time
            for (BigInteger i = BigInteger.ZERO; i.compareTo(BigInteger.valueOf(100000000000L)) < 0; i = i.add(BigInteger.ONE)) {
                Math.sqrt(i.doubleValue());
            }
        }

        // Get total CPU time for all threads
        long totalCpuTime = 0;
        ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
        for (long threadId : threadMXBean.getAllThreadIds()) {
            long cpuTime = threadMXBean.getThreadCpuTime(threadId);
            totalCpuTime += cpuTime;
        }

        System.out.println("Total CPU time for all threads: " + totalCpuTime + " nanoseconds");
    }
}