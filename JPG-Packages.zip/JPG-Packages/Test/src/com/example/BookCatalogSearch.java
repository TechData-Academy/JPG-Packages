package com.example;

// Java

import java.util.HashMap;
import java.util.Map;

class Book2 {
    private String isbn;
    private String title;

    public Book2(String isbn, String title) {
        this.isbn = isbn;
        this.title = title;
    }

    public  
 String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return  
 title;
    }
}

public class BookCatalogSearch {

    public static void main(String[] args) {
        // Create a HashMap to represent the book catalog
        Map<String, Book2> bookCatalog = new HashMap<>();

        // Populate the catalog with book data
        bookCatalog.put("978-0321765723", new Book2("978-0321765723", "The Lord of the Rings"));
        bookCatalog.put("978-0743273565", new Book2("978-0743273565", "Pride and Prejudice"));
        bookCatalog.put("978-0345391803", new Book2("978-0345391803", "The Hitchhiker's Guide to the Galaxy"));
        // ... add more books ...

        // Target ISBN to find
        String targetIsbn = "978-0345391803";

        // Search for the book using the ISBN
        Book2 foundBook = bookCatalog.get(targetIsbn);

        // Print the result
        if (foundBook != null) {
            System.out.println("Found the book: " + foundBook.getTitle());
        } else {
            System.out.println("Book not found.");
        }
    }
}