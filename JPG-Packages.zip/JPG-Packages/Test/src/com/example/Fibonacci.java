package com.example;

//Java
public class Fibonacci {

 public static int fibonacci(int n) {
     if (n <= 1) {
         return n; // Base cases: 0th and 1st Fibonacci numbers are 0 and 1
     } else {
         return fibonacci(n - 1) + fibonacci(n - 2); // Recursive call
     }
 }

 public static void main(String[] args) {
     int n = 45; // Calculate the 10th Fibonacci number
     int result = fibonacci(n);
     System.out.println("The " + n + "th Fibonacci number is: " + result);   

 }
}

