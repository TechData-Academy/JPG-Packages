package com.example;

//Java

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DataProcessor {

    public static void main(String[] args) {
        DataProcessor processor = new DataProcessor();
        List<Data> dataList = processor.generateData(1000); // Generate a list of 10,000 Data objects

        long startTime = System.currentTimeMillis();
        processor.processData(dataList);
        long endTime = System.currentTimeMillis();

        System.out.println("Processing time: " + (endTime - startTime) + " ms");
    }

    // Method to process the data (potentially with a performance bottleneck)
    public void processData(List<Data> dataList) {
        for (Data data : dataList) {
            // Simulate a complex calculation or operation
            // This example uses a simple sleep to simulate a delay
            try {
                Thread.sleep(1); // Sleep for 1 millisecond
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to generate sample data
    private List<Data> generateData(int count) {
        List<Data> dataList = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < count; i++) {
            dataList.add(new Data(random.nextInt(100), "Data " + i));
        }
        return dataList;
    }

    // Sample Data class
    private static class Data {
        private int value;
        private String label;

        public Data(int value, String label) {
            this.value = value;
            this.label = label;
        }

        // Getters and setters (optional)
        public int getValue() {
            return value;
        }

        public void setValue(int value) {
            this.value = value;
        }

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;  

        }
    }
}