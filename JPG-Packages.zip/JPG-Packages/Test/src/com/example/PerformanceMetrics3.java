package com.example;


import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;
import java.util.List;

public class PerformanceMetrics3 {

	  public static void main(String[] args) {
	        long startTime = System.nanoTime();

	        // Generate a small amount of garbage
	        List<Object> objects = new ArrayList<>();
	        for (int i = 0; i < 500; i++) { // Create 500 objects
	            objects.add(new Object()); 
	        }
	        objects = null; // Dereference the list for GC

	        // Trigger garbage collection explicitly
	        System.gc(); 

	        long endTime = System.nanoTime();
	        long elapsedTime = endTime - startTime;

	        // Calculate garbage collection overhead
	        long totalGcTime = 0;
	        for (GarbageCollectorMXBean gcBean : ManagementFactory.getGarbageCollectorMXBeans()) {
	            totalGcTime += gcBean.getCollectionTime();  

	        }

	        double gcOverhead = (double) totalGcTime / elapsedTime * 100;

	        // Print the results
	        System.out.println("Elapsed Time: " + elapsedTime + " nanoseconds");
	        System.out.println("Total GC Time: " + totalGcTime + " nanoseconds");
	        System.out.println("Garbage Collection Overhead: " + gcOverhead + "%");
	    }
	}