package Test;

public class PerformanceTest {

    public static void main(String[] args) {

        // Record the start time
        long startTime = System.nanoTime();

        // Run the code you want to measure
        long result = fibonacci(43); 

        // Record the end time
        long endTime = System.nanoTime();

        // Calculate the execution time in nanoseconds
        long executionTime = endTime - startTime;

        // Calculate memory usage
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
        // Run garbage collector to get a more accurate memory usage
        runtime.gc(); 
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

        System.out.println("Result: " + result);
        System.out.println("Execution time: " + executionTime + " ns");
        System.out.println("Memory used: " + memoryUsed + " bytes");
    }

    // Example function - calculate the nth Fibonacci number
    public static long fibonacci(int n) {
        if (n <= 1) {
            return n;
        }
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}
