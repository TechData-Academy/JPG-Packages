package Test;

//java


import java.util.HashMap;
import java.util.Map;

public class HotspotExample {

    public static void main(String[] args) {
        // Create and populate the HashMap
        Map<Integer, String> data = new HashMap<>();
        for (int i = 0; i < 1000000; i++) {
            data.put(i, "Value " + i);
        }

        // Print memory usage before the workload
        long memoryBefore = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        System.out.println("Memory used before: " + memoryBefore / (1024 * 1024) + " MB");

        // Start tracking the time
        long startTime = System.nanoTime();

        // Simulate some work that might create a hotspot
        for (int i = 0; i < 10000000; i++) {
            String value = data.get(i % 1000000); // Frequent access to a small subset of keys
            // Simulate processing of the retrieved value
        }

        // Stop tracking the time
        long endTime = System.nanoTime();

        // Print memory usage after the workload
        long memoryAfter = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        System.out.println("Memory used after: " + memoryAfter / (1024 * 1024) + " MB");

        // Calculate and print the execution time
        long executionTime = endTime - startTime;
        System.out.println("Execution time: " + executionTime + " ns");

        // Print JIT compilation information (if enabled with -XX:+PrintCompilation)
        // You'll see this output in the console if you enable the flag during execution
    }
}