package Test;

//Java
import org.openjdk.jmh.annotations.*;
import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)  

@State(Scope.Benchmark)  

public class StringConcatenationBenchmark {

    @Param({"100", "1000", "10000"})
    private int stringCount;

    @Benchmark
    @Fork(value = 1, warmups = 1, jvmArgs = {"-Xms2G", "-Xmx2G"})
    public String stringConcatenation() {
        String result = "";
        for (int i = 0; i < stringCount; i++) {
            result += "hello";
        }
        return result;
    }

    @Benchmark
    @Fork(value = 1, warmups = 1, jvmArgs = {"-Xms2G", "-Xmx2G"})
    public String stringBuilderConcatenation() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < stringCount; i++) {
            sb.append("hello");
        }
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        org.openjdk.jmh.Main.main(args);
    }
}