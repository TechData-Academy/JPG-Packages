package Test;

import java.util.*;

public class EnumCollectionsComparison {

    enum DayOfWeek {
        MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
    }

    public static void main(String[] args) {
        int numDays = 1000000; // Number of iterations

        // Run performance tests for EnumSet
        runPerformanceTest("EnumSet - Add", () -> enumSetAdd(numDays));
        runPerformanceTest("EnumSet - Contains", () -> enumSetContains(numDays));

        // Run performance tests for EnumMap
        runPerformanceTest("EnumMap - Put", () -> enumMapPut(numDays));
        runPerformanceTest("EnumMap - Get", () -> enumMapGet(numDays));

        // Compare with regular HashSet and HashMap
        runPerformanceTest("HashSet - Add", () -> hashSetAdd(numDays));
        runPerformanceTest("HashSet - Contains", () -> hashSetContains(numDays));
        runPerformanceTest("HashMap - Put", () -> hashMapPut(numDays));
        runPerformanceTest("HashMap - Get", () -> hashMapGet(numDays));
    }

    // EnumSet operations
    static void enumSetAdd(int numDays) {
        for (int i = 0; i < numDays; i++) {
            EnumSet<DayOfWeek> days = EnumSet.noneOf(DayOfWeek.class);
            days.add(DayOfWeek.MONDAY);
            days.add(DayOfWeek.WEDNESDAY);
            days.add(DayOfWeek.FRIDAY);
        }
    }

    static void enumSetContains(int numDays) {
        EnumSet<DayOfWeek> days = EnumSet.range(DayOfWeek.MONDAY, DayOfWeek.FRIDAY);
        for (int i = 0; i < numDays; i++) {
            boolean contains = days.contains(DayOfWeek.WEDNESDAY);
        }
    }

    // EnumMap operations
    static void enumMapPut(int numDays) {
        for (int i = 0; i < numDays; i++) {
            EnumMap<DayOfWeek, String> schedule = new EnumMap<>(DayOfWeek.class);
            schedule.put(DayOfWeek.MONDAY, "Meeting");
            schedule.put(DayOfWeek.WEDNESDAY, "Workout");
            schedule.put(DayOfWeek.FRIDAY, "Shopping");
        }
    }

    static void enumMapGet(int numDays) {
        EnumMap<DayOfWeek, String> schedule = new EnumMap<>(DayOfWeek.class);
        schedule.put(DayOfWeek.MONDAY, "Meeting");
        schedule.put(DayOfWeek.WEDNESDAY, "Workout");
        schedule.put(DayOfWeek.FRIDAY, "Shopping");
        for (int i = 0; i < numDays; i++) {
            String activity = schedule.get(DayOfWeek.WEDNESDAY);
        }
    }

    // HashSet operations
    static void hashSetAdd(int numDays) {
        for (int i = 0; i < numDays; i++) {
            Set<DayOfWeek> days = new HashSet<>();
            days.add(DayOfWeek.MONDAY);
            days.add(DayOfWeek.WEDNESDAY);
            days.add(DayOfWeek.FRIDAY);
        }
    }

    static void hashSetContains(int numDays) {
        Set<DayOfWeek> days = new HashSet<>();
        days.add(DayOfWeek.MONDAY);
        days.add(DayOfWeek.WEDNESDAY);
        days.add(DayOfWeek.FRIDAY);
        for (int i = 0; i < numDays; i++) {
            boolean contains = days.contains(DayOfWeek.WEDNESDAY);
        }
    }

    // HashMap operations
    static void hashMapPut(int numDays) {
        for (int i = 0; i < numDays; i++) {
            Map<DayOfWeek, String> schedule = new HashMap<>();
            schedule.put(DayOfWeek.MONDAY, "Meeting");
            schedule.put(DayOfWeek.WEDNESDAY, "Workout");
            schedule.put(DayOfWeek.FRIDAY, "Shopping");
        }
    }

    static void hashMapGet(int numDays) {
        Map<DayOfWeek, String> schedule = new HashMap<>();
        schedule.put(DayOfWeek.MONDAY, "Meeting");
        schedule.put(DayOfWeek.WEDNESDAY, "Workout");
        schedule.put(DayOfWeek.FRIDAY, "Shopping");
        for (int i = 0; i < numDays; i++) {
            String activity = schedule.get(DayOfWeek.WEDNESDAY);
        }
    }

    static void runPerformanceTest(String testName, Runnable testMethod) {
        long startTime = System.nanoTime();
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();  


        testMethod.run(); // Run the test method

        long endTime = System.nanoTime();
        runtime.gc();
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

        long executionTime = endTime - startTime;
        System.out.println(testName + ":");
        System.out.println("  Execution time: " + executionTime + " ns");
        System.out.println("  Memory used: " + memoryUsed + " bytes");
        System.out.println("----------------------");
    }
}
