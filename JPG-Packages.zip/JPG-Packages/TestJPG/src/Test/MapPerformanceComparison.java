package Test;

//Java
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapPerformanceComparison {

    public static void main(String[] args) {
        int numElements = 1000000; // Number of elements to insert

        // HashMap Performance Test with larger initial capacity and optimized put
        runPerformanceTest("HashMap", new HashMap<>(numElements), numElements);

        // TreeMap Performance Test
        runPerformanceTest("TreeMap", new TreeMap<>(), numElements);
    }

    static void runPerformanceTest(String mapName, Map<Integer, String> map, int numElements) {
        long startTime, endTime;
        Runtime runtime = Runtime.getRuntime();

        // Pre-generate string values to avoid repeated concatenation
        String[] values = new String[numElements];
        for (int i = 0; i < numElements; i++) {
            values[i] = "Value " + i;
        }

        // Warm up the JVM 
        for (int i = 0; i < numElements / 10; i++) {
            map.put(i, values[i]);
        }
        map.clear();

        // Insertion Test
        startTime = System.nanoTime();
        long usedMemoryBeforeInsertion = runtime.totalMemory() - runtime.freeMemory();
        for (int i = 0; i < numElements; i++) {
            map.put(i, values[i]); // Use pre-generated values
        }
        endTime = System.nanoTime();
        runtime.gc();
        long usedMemoryAfterInsertion = runtime.totalMemory() - runtime.freeMemory();
        long insertionMemory = usedMemoryAfterInsertion - usedMemoryBeforeInsertion;
        long insertionTime = endTime - startTime;

        // Retrieval Test
        startTime = System.nanoTime();
        long usedMemoryBeforeRetrieval = runtime.totalMemory() - runtime.freeMemory();
        for (int i = 0; i < numElements; i++) {
            String value = map.get(i);
        }
        endTime = System.nanoTime();
        runtime.gc();
        long usedMemoryAfterRetrieval = runtime.totalMemory() - runtime.freeMemory();
        long retrievalMemory = usedMemoryAfterRetrieval - usedMemoryBeforeRetrieval;
        long retrievalTime = endTime - startTime;

        System.out.println(mapName + ":");
        System.out.println("  Insertion Time: " + insertionTime + " nanoseconds");
        System.out.println("  Insertion Memory: " + insertionMemory + " bytes");
        System.out.println("  Retrieval Time: " + retrievalTime + " nanoseconds");
        System.out.println("  Retrieval Memory: " + retrievalMemory + " bytes");
        System.out.println("----------------------");
    }
}