package Test;

//Java
import java.util.*;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.atomic.AtomicBoolean;  

import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;  


class Book2 {
    private String title;
    private String isbn;

    public Book2(String title, String isbn) {
        this.title = title;
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;  

    }

    public String getIsbn() {
        return isbn;
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", isbn='" + isbn  
 + '\'' +
                '}';
    }
}

public class LibrarySearch {

    static List<Book> books;
    static Book targetBook;
    static Map<String, Book> bookCatalog;

    public static void main(String[] args) {
        // Initialize the library with a large number of books
        int numBooks = 1000000; // You can adjust this
        books = generateBooks(numBooks);
        targetBook = books.get(new Random().nextInt(numBooks));
        bookCatalog = books.stream().collect(Collectors.toMap(Book::getIsbn, book -> book));

        // Run the performance tests
        runPerformanceTest("Linear Search", LibrarySearch::linearSearch);
        runPerformanceTest("HashMap Search", LibrarySearch::hashMapSearch);
        runPerformanceTest("Parallel Stream Search", LibrarySearch::parallelStreamSearch);
        runPerformanceTest("Fork/Join Search", LibrarySearch::forkJoinSearch);
    }

    // Generate a list of books with random titles and ISBNs
    static List<Book> generateBooks(int numBooks) {
        List<Book> bookList = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < numBooks; i++) {
            String title = "Book " + random.nextInt(10000);
            String isbn = UUID.randomUUID().toString();
            bookList.add(new Book(title, isbn));
        }
        return bookList;
    }

    // Linear Search (Brute Force)
    static Book linearSearch() {
        for (Book book : books) {
            if (book.getTitle().equals(targetBook.getTitle())) {
                return book;
            }
        }
        return null;
    }

    // HashMap Search
    static Book hashMapSearch() {
        return bookCatalog.get(targetBook.getIsbn());
    }

    // Highly Optimized Parallel Stream Search with Custom Thread Pool and Interruption
    static Book parallelStreamSearch() {
        ForkJoinPool customThreadPool = new ForkJoinPool(6); // Smaller thread pool
        try {
            AtomicReference<Book> result = new AtomicReference<>(null); // AtomicReference for result
            customThreadPool.submit(
                    () -> books.parallelStream()
                            .filter(book -> {
                                if (Thread.currentThread().isInterrupted() || result.get() != null) {
                                    return false; // Check interruption and result
                                }
                                return book.getTitle().equals(targetBook.getTitle());
                            })
                            .findFirst()
                            .ifPresent(result::set) // Set the result if found
            ).get();
            return result.get(); // Return the result from AtomicReference
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Highly Optimized Fork/Join Search with Reduced Thread Pool and Work-Stealing
    static Book forkJoinSearch() {
        int numThreads = 6; // Reduced thread pool size
        ForkJoinPool forkJoinPool = new ForkJoinPool(numThreads,
                ForkJoinPool.defaultForkJoinWorkerThreadFactory,
                null, true); // Enable work-stealing
        int threshold = 250000; // Experiment with this value
        Book[] booksArray = books.toArray(new Book[0]);
        AtomicBoolean found = new AtomicBoolean(false);
        return forkJoinPool.invoke(new ForkJoinSearchTask(booksArray, 0, books.size(), threshold, found));
    }

    static class ForkJoinSearchTask extends RecursiveTask<Book> {
        private final Book[] booksArray;
        int start;
        int end;
        int threshold;
        AtomicBoolean found; // Shared flag for early termination

        public ForkJoinSearchTask(Book[] booksArray, int start, int end, int threshold, AtomicBoolean found) {
            this.booksArray = booksArray;
            this.start = start;
            this.end = end;
            this.threshold = threshold;
            this.found = found;
        }

        @Override
        protected Book compute() {
            if (found.get()) {
                return null; // Another task already found the book
            }

            int size = end - start;
            if (size <= threshold) {
                // Sequential search within the sub-array
                for (int i = start; i < end; i++) {
                    if (booksArray[i].getTitle().equals(targetBook.getTitle())) {
                        found.set(true); // Set the flag to signal other tasks
                        return booksArray[i];
                    }
                }
                return null;
            } else {
                int mid = start + (size / 2);
                ForkJoinSearchTask leftTask = new ForkJoinSearchTask(booksArray, start, mid, threshold, found);
                ForkJoinSearchTask rightTask = new ForkJoinSearchTask(booksArray, mid, end, threshold, found);

                // Optimized task invocation
                rightTask.fork();
                Book leftResult = leftTask.compute();
                if (leftResult != null) {
                    return leftResult; // If found in the left, no need to wait for the right
                }
                Book rightResult = rightTask.join();
                return rightResult;
            }
        }
    }

    static void runPerformanceTest(String testName, Runnable testMethod) {
        long startTime = System.nanoTime();
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();  


        testMethod.run(); // Run the search method

        long endTime = System.nanoTime();
        runtime.gc();
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

        long executionTime = endTime - startTime;
        System.out.println(testName + ":");
        System.out.println("Execution time: " + executionTime + " ns");
        System.out.println("Memory used: " + memoryUsed + " bytes");
        System.out.println("----------------------");
    }
}