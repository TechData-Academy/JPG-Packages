package Test;

//Java
import java.util.*;

class Book {
    private String title;
    private String author;
    // ... other fields

    // Constructor and getters (for testing)
    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;  

    }

    // Poor hashCode() implementation - only considers title
    @Override
    public int hashCode() {
        return title.hashCode();
    }

    // Inefficient equals() implementation - compares all fields
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;  


        Book book = (Book) obj;
        return title.equals(book.title) &&
                author.equals(book.author);  

                // ... compare other fields
    }
}

public class HashCodeEqualsComparison {

    public static void main(String[] args) {
        int numBooks = 100000; // Number of books

        // Run performance tests with poor hashCode()
        runPerformanceTest("Poor hashCode()", () -> testHashMap(createBooksWithPoorHashCode(numBooks)));

        // Run performance tests with improved hashCode()
        runPerformanceTest("Improved hashCode()", () -> testHashMap(createBooksWithImprovedHashCode(numBooks)));

        // Set-based example
        setBasedExample();
    }

    // Create books with poor hashCode() implementation
    static List<Book> createBooksWithPoorHashCode(int numBooks) {
        List<Book> books = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < numBooks; i++) {
            books.add(new Book("Book " + random.nextInt(1000), "Author " + i));
        }
        return books;
    }

    // Create books with improved hashCode() implementation
    static List<Book> createBooksWithImprovedHashCode(int numBooks) {
        List<Book> books = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < numBooks; i++) {
            books.add(new Book("Book " + random.nextInt(1000), "Author " + i) {
                @Override
                public int hashCode() {
                    int result = 17; // Prime number for better distribution
                    result = 31 * result + getTitle().hashCode();
                    result = 31 * result + getAuthor().hashCode();
                    // ... include other relevant fields in the hash code calculation
                    return result;
                }
            });
        }
        return books;
    }

    // Test HashMap performance with a list of books
    static void testHashMap(List<Book> books) {
        Map<Book, Integer> bookMap = new HashMap<>();
        // Add books to the map
        for (int i = 0; i < books.size(); i++) {
            bookMap.put(books.get(i), i);
        }
        // Retrieve a book from the map
        Book targetBook = books.get(books.size() / 2);
        bookMap.get(targetBook);
    }

    // Set-based example
    static void setBasedExample() {
        List<Integer> list1 = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> list2 = Arrays.asList(3, 5, 7, 8);

        // Traditional approach (nested loops - O(n^2))
        List<Integer> commonElementsTraditional = new ArrayList<>();
        for (int num1 : list1) {
            for (int num2 : list2) {
                if (num1 == num2) {
                    commonElementsTraditional.add(num1);
                    break; // Avoid duplicates
                }
            }
        }

        // Set-based approach (retainAll - O(n))
        Set<Integer> set1 = new HashSet<>(list1);
        Set<Integer> set2 = new HashSet<>(list2);
        set1.retainAll(set2); // Intersection of sets

        System.out.println("Common elements (traditional): " + commonElementsTraditional);
        System.out.println("Common elements (set-based): " + set1);
    }

    static void runPerformanceTest(String testName, Runnable testMethod) {
        long startTime = System.nanoTime();
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();  


        testMethod.run(); // Run the test method

        long endTime = System.nanoTime();
        runtime.gc();
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

        long executionTime = endTime - startTime;
        System.out.println(testName + ":");
        System.out.println("  Execution time: " + executionTime + " ns");
        System.out.println("  Memory used: " + memoryUsed + " bytes");
        System.out.println("----------------------");
    }
}