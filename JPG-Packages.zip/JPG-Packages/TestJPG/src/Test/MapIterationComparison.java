package Test;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MapIterationComparison {

    public static void main(String[] args) {
        int numProducts = 1000000; // Number of products
        Map<String, Integer> productInventory = generateProductInventory(numProducts);

        // Run performance tests
        runPerformanceTest("entrySet() Iteration", () -> iterateWithEntrySet(productInventory));
        runPerformanceTest("keySet() Iteration", () -> iterateWithKeySet(productInventory));
    }

    // Generate a map of product names and quantities
    static Map<String, Integer> generateProductInventory(int numProducts) {
        Map<String, Integer> inventory = new HashMap<>();
        Random random = new Random();
        for (int i = 0; i < numProducts; i++) {
            inventory.put("Product " + i, random.nextInt(100));
        }
        return inventory;
    }

    // Iteration using entrySet()
    static void iterateWithEntrySet(Map<String, Integer> inventory) {
        for (Map.Entry<String, Integer> entry : inventory.entrySet()) {
            String productName = entry.getKey();
            int quantity = entry.getValue();  

            // Perform some operation with productName and quantity
            // ...
        }
    }

    // Iteration using keySet()
    static void iterateWithKeySet(Map<String, Integer> inventory) {
        for (String productName : inventory.keySet()) {
            int quantity = inventory.get(productName);
            // Perform some operation with productName and quantity
            // ...
        }
    }

    static void runPerformanceTest(String testName, Runnable testMethod) {
        long startTime = System.nanoTime();
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();  


        testMethod.run(); // Run the iteration method

        long endTime = System.nanoTime();
        runtime.gc();
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

        long executionTime = endTime - startTime;
        System.out.println(testName + ":");
        System.out.println("  Execution time: " + executionTime + " ns");
        System.out.println("  Memory used: " + memoryUsed + " bytes");
        System.out.println("----------------------");
    }
}