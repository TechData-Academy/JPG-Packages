package Test;

//Java
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class SortingComparison  
 {

    public static void main(String[] args) {
        int numNames = 10000; // Number of names to sort
        List<String> names = generateRandomNames(numNames);

        // Create copies of the list for each sorting algorithm
        List<String> namesForBubbleSort = new ArrayList<>(names);
        List<String> namesForQuickSort = new ArrayList<>(names);
        List<String> namesForMergeSort = new ArrayList<>(names);

        // Run performance tests
        runPerformanceTest("Bubble Sort", () -> bubbleSort(namesForBubbleSort));
        runPerformanceTest("Quick Sort", () -> quickSort(namesForQuickSort, 0, namesForQuickSort.size() - 1));
        runPerformanceTest("Merge Sort", () -> mergeSort(namesForMergeSort, 0, namesForMergeSort.size() - 1));
        runPerformanceTest("Collections.sort (Timsort)", () -> Collections.sort(names));
    }

    // Generate a list of random names
    static List<String> generateRandomNames(int numNames) {
        List<String> nameList = new ArrayList<>();
        Random random = new Random();
        String[] sampleNames = {"Alice", "Bob", "Charlie", "David", "Emily", "Frank", "Grace", "Henry", "Isabella", "Jack"};
        for (int i = 0; i < numNames; i++) {
            nameList.add(sampleNames[random.nextInt(sampleNames.length)] + " " + i);
        }
        return nameList;
    }

    // Bubble Sort (O(n^2))
    static void bubbleSort(List<String> list) {
        int n = list.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (list.get(j).compareTo(list.get(j  
 + 1)) > 0) {
                    // Swap adjacent elements
                    Collections.swap(list, j, j + 1);
                }
            }
        }
    }

    // Quick Sort (O(n log n) average)
    static void quickSort(List<String> list, int low, int high) {
        if (low < high) {
            int pi = partition(list, low, high);
            quickSort(list, low, pi - 1);
            quickSort(list, pi + 1, high);
        }
    }

    static  
 int partition(List<String> list, int low, int high) {
        String pivot = list.get(high);
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (list.get(j).compareTo(pivot)  
 <= 0) {
                i++;
                Collections.swap(list, i, j);
            }
        }
        Collections.swap(list, i + 1, high);
        return i + 1;  

    }

    // Merge Sort (O(n log n))
    static void mergeSort(List<String> list, int l, int r) {
        if (l < r) {
            int m = l + (r - l) / 2;
            mergeSort(list, l, m);
            mergeSort(list, m + 1, r);
            merge(list, l, m, r);
        }
    }

    static void merge(List<String> list, int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;

        String[] L = new String[n1];
        String[] R = new String[n2];

        for (int i = 0; i < n1; ++i)
            L[i] = list.get(l + i);
        for (int j = 0; j < n2; ++j)
            R[j] = list.get(m + 1 + j);

        int i = 0, j = 0;
        int k = l;
        while (i < n1 && j < n2) {
            if (L[i].compareTo(R[j])  
 <= 0) {
                list.set(k, L[i]);
                i++;
            } else {
                list.set(k, R[j]);
                j++;
            }
            k++;
        }

        while (i < n1) {
            list.set(k, L[i]);
            i++;
            k++;
        }

        while (j < n2) {
            list.set(k, R[j]);
            j++;
            k++;
        }
    }

    static void runPerformanceTest(String testName, Runnable testMethod) {
        long startTime = System.nanoTime();
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();  


        testMethod.run(); // Run the sorting algorithm

        long endTime = System.nanoTime();
        runtime.gc();
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

        long executionTime = endTime - startTime;
        System.out.println(testName + ":");
        System.out.println("Execution time: " + executionTime + " ns");
        System.out.println("Memory used: " + memoryUsed + " bytes");
        System.out.println("----------------------");
    }
}
