package Test;

public class Fibonacci {

    public static int fibonacci(int n) {
        if (n <= 1) {
            return n; 
        } else {
            return fibonacci(n - 1) + fibonacci(n - 2); 
        }
    }

    public static void main(String[] args) {
        int n = 45;  
 

        // Record the start time
        long startTime = System.nanoTime();

        // Calculate the nth Fibonacci number
        int result = fibonacci(n);

        // Record the end time
        long endTime = System.nanoTime();

        // Calculate the execution time in nanoseconds
        long executionTime = endTime - startTime;

        // Calculate memory usage
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
        runtime.gc(); // Run garbage collector
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

        System.out.println("The " + n + "th Fibonacci number is: " + result);
        System.out.println("Execution time: " + executionTime + " ns");
        System.out.println("Memory used: " + memoryUsed + " bytes");
    }
}
