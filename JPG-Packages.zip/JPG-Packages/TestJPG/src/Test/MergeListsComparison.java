package Test;

//Java
import java.util.*;

public class MergeListsComparison {

    public static void main(String[] args) {
        int numElements = 100000; // Number of elements in each list
        List<String> list1 = generateRandomStrings(numElements);
        List<String> list2 = generateRandomStrings(numElements);

        // Run performance tests
        runPerformanceTest("Traditional Merge", () -> mergeListsTraditional(list1, list2));
        runPerformanceTest("Set-Based Merge", () -> mergeListsSetBased(list1, list2));
    }

    // Generate a list of random strings
    static List<String> generateRandomStrings(int numElements) {
        List<String> stringList = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < numElements; i++) {
            stringList.add("String " + random.nextInt(numElements / 2)); // Introduce some duplicates
        }
        return stringList;
    }

    // Traditional approach (manual iteration and duplicate check)
    static List<String> mergeListsTraditional(List<String> list1, List<String> list2) {
        List<String> mergedList = new ArrayList<>();
        for (String item : list1) {
            if (!mergedList.contains(item)) {
                mergedList.add(item);
            }
        }
        for (String item : list2) {
            if (!mergedList.contains(item)) {
                mergedList.add(item);
            }
        }
        return mergedList;
    }

    // Set-based approach (HashSet for deduplication)
    static List<String> mergeListsSetBased(List<String> list1, List<String> list2) {
        Set<String> mergedSet = new HashSet<>();
        mergedSet.addAll(list1);
        mergedSet.addAll(list2);
        return new ArrayList<>(mergedSet);
    }

    static void runPerformanceTest(String testName, Runnable testMethod) {
        long startTime = System.nanoTime();
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();  


        testMethod.run(); // Run the merge method

        long endTime = System.nanoTime();
        runtime.gc();
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

        long executionTime = endTime - startTime;
        System.out.println(testName + ":");
        System.out.println("  Execution time: " + executionTime + " ns");
        System.out.println("  Memory used: " + memoryUsed + " bytes");
        System.out.println("----------------------");
    }
}
