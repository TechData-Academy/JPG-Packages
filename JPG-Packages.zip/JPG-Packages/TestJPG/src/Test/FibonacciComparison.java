package Test;

//Java
public class FibonacciComparison {

    // Original recursive Fibonacci (for comparison)
    public static int fibonacciRecursive(int n) {
        if (n <= 1) {
            return n;
        } else {
            return fibonacciRecursive(n - 1) + fibonacciRecursive(n - 2);
        }
    }

    // Iterative Fibonacci
    public static int fibonacciIterative(int n) {
        if (n <= 1) {
            return n;
        }

        int prev = 0, current = 1;
        for (int i = 2; i <= n; i++) {
            int next = prev + current;
            prev = current;
            current = next;
        }
        return current; 

    }

    // Tail-recursive Fibonacci
    public static int fibonacciTailRecursive(int n) {
        return fibonacciHelper(n, 0, 1);
    }

    private static int fibonacciHelper(int n, int a, int b) {
        if (n == 0) {
            return a;
        } else {
            return fibonacciHelper(n - 1, b, a + b);
        }
    }

    public static void main(String[] args) {
        int n = 50; // You can adjust this value

        runPerformanceTest("Recursive Fibonacci", () -> fibonacciRecursive(n));
        runPerformanceTest("Iterative Fibonacci", () -> fibonacciIterative(n));
        runPerformanceTest("Tail-Recursive Fibonacci", () -> fibonacciTailRecursive(n));
    }

    static void runPerformanceTest(String testName, Runnable testMethod) {
        long startTime = System.nanoTime();
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();  


        testMethod.run(); // Run the Fibonacci method

        long endTime = System.nanoTime();
        runtime.gc();
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        long memoryUsed = usedMemoryAfter - usedMemoryBefore;

        long executionTime = endTime - startTime;
        System.out.println(testName + ":");
        System.out.println("  Execution time: " + executionTime + " ns");
        System.out.println("  Memory used: " + memoryUsed + " bytes");
        System.out.println("----------------------");
    }
}